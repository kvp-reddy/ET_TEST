CREATE DATABASE  IF NOT EXISTS `test` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `test`;
-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: test
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `addressid` int(11) NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `country_id` int(11) unsigned NOT NULL,
  `doorno` varchar(45) DEFAULT NULL,
  `streetname` varchar(50) NOT NULL,
  `area` varchar(45) DEFAULT NULL,
  `pincode` int(10) DEFAULT NULL,
  PRIMARY KEY (`addressid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,1,3,2,'3-22-15151','dkdkd',NULL,500072);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `cityid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`cityid`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,'Adoni'),(2,'Ahmadnagar'),(3,'Allappuzha (Alleppey)'),(4,'Ambattur'),(5,'Amroha'),(6,'Balurghat'),(7,'Berhampore (Baharampur)'),(8,'Bhavnagar'),(9,'Bhilwara'),(10,'Bhimavaram'),(11,'Bhopal'),(12,'Bhusawal'),(13,'Bijapur'),(14,'Chandrapur'),(15,'Chapra'),(16,'Dhule (Dhulia)'),(17,'Etawah'),(18,'Firozabad'),(19,'Gandhinagar'),(20,'Gulbarga'),(21,'Haldia'),(22,'Halisahar'),(23,'Hoshiarpur'),(24,'Hubli-Dharwad'),(25,'Jaipur'),(26,'Jhansi'),(27,'Jodhpur'),(28,'Kamarhati'),(29,'Kanchrapara'),(30,'Karnal'),(31,'Katihar'),(32,'Kumbakonam'),(33,'Miraj'),(34,'Munger (Monghyr)'),(35,'Mysore'),(36,'Nagaon'),(37,'Palghat (Palakkad)'),(38,'Parbhani'),(39,'Pathankot'),(40,'Patiala'),(41,'Pudukkottai'),(42,'Pune'),(43,'Purnea (Purnia)'),(44,'Rae Bareli'),(45,'Rajkot'),(46,'Rampur'),(47,'Ranchi'),(48,'Sambhal'),(49,'Satna'),(50,'Shimoga'),(51,'Shivapuri'),(52,'Siliguri (Shiliguri)'),(53,'Tambaram'),(54,'Udaipur'),(55,'Uluberia'),(56,'Uttarpara-Kotrung'),(57,'Valparai'),(58,'Varanasi (Benares)'),(59,'Vijayawada'),(60,'Yamuna Nagar');
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'Afghanistan'),(2,'Algeria'),(3,'American Samoa'),(4,'Angola'),(5,'Anguilla'),(6,'Argentina'),(7,'Armenia'),(8,'Australia'),(9,'Austria'),(10,'Azerbaijan'),(11,'Bahrain'),(12,'Bangladesh'),(13,'Belarus'),(14,'Bolivia'),(15,'Brazil'),(16,'Brunei'),(17,'Bulgaria'),(18,'Cambodia'),(19,'Cameroon'),(20,'Canada'),(21,'Chad'),(22,'Chile'),(23,'China'),(24,'Colombia'),(25,'Congo, The Democratic Republic of the'),(26,'Czech Republic'),(27,'Dominican Republic'),(28,'Ecuador'),(29,'Egypt'),(30,'Estonia'),(31,'Ethiopia'),(32,'Faroe Islands'),(33,'Finland'),(34,'France'),(35,'French Guiana'),(36,'French Polynesia'),(37,'Gambia'),(38,'Germany'),(39,'Greece'),(40,'Greenland'),(41,'Holy See (Vatican City State)'),(42,'Hong Kong'),(43,'Hungary'),(44,'India'),(45,'Indonesia'),(46,'Iran'),(47,'Iraq'),(48,'Israel'),(49,'Italy'),(50,'Japan'),(51,'Kazakstan'),(52,'Kenya'),(53,'Kuwait'),(54,'Latvia'),(55,'Liechtenstein'),(56,'Lithuania'),(57,'Madagascar'),(58,'Malawi'),(59,'Malaysia'),(60,'Mexico'),(61,'Moldova'),(62,'Morocco'),(63,'Mozambique'),(64,'Myanmar'),(65,'Nauru'),(66,'Nepal'),(67,'Netherlands'),(68,'New Zealand'),(69,'Nigeria'),(70,'North Korea'),(71,'Oman'),(72,'Pakistan'),(73,'Paraguay'),(74,'Peru'),(75,'Philippines'),(76,'Poland'),(77,'Puerto Rico'),(78,'Romania'),(79,'Runion'),(80,'Russian Federation'),(81,'Saint Vincent and the Grenadines'),(82,'Saudi Arabia'),(83,'Senegal'),(84,'Slovakia'),(85,'South Africa'),(86,'South Korea'),(87,'Spain'),(88,'Sri Lanka'),(89,'Sudan'),(90,'Sweden'),(91,'Switzerland'),(92,'Taiwan'),(93,'Tanzania'),(94,'Thailand'),(95,'Tonga'),(96,'Tunisia'),(97,'Turkey'),(98,'Turkmenistan'),(99,'Tuvalu'),(100,'Ukraine'),(101,'United Arab Emirates'),(102,'United Kingdom'),(103,'United States'),(104,'Venezuela'),(105,'Vietnam'),(106,'Virgin Islands, U.S.'),(107,'Yemen'),(108,'Yugoslavia'),(109,'Zambia');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'design'),(2,'coding'),(3,'testing'),(4,'production');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `designation_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designation`
--

LOCK TABLES `designation` WRITE;
/*!40000 ALTER TABLE `designation` DISABLE KEYS */;
INSERT INTO `designation` VALUES (1,'junior software engineer'),(2,'senior software engineer'),(3,'assistant manager'),(4,'manager');
/*!40000 ALTER TABLE `designation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `Empid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `First_name` varchar(45) NOT NULL,
  `Last_name` varchar(45) NOT NULL,
  `Department_id` int(10) NOT NULL,
  `Joined_date` date NOT NULL,
  `working_City_id` int(11) NOT NULL,
  `working_State_id` int(11) NOT NULL,
  `working_Country_id` int(11) NOT NULL,
  `Perm_Address_id` int(10) DEFAULT NULL,
  `Last_update` varchar(45) NOT NULL DEFAULT 'CURRENT_TIMESTAMP',
  `Designation_id` int(11) NOT NULL,
  `salary` int(10) NOT NULL,
  `DOB` date NOT NULL,
  PRIMARY KEY (`Empid`),
  KEY `city_idx` (`working_City_id`),
  KEY `country_idx` (`working_Country_id`),
  KEY `state_idx` (`working_State_id`),
  KEY `department_idx` (`Department_id`),
  KEY `designation_idx` (`Designation_id`),
  KEY `address_idx` (`Perm_Address_id`),
  CONSTRAINT `address` FOREIGN KEY (`Perm_Address_id`) REFERENCES `address` (`addressid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `city` FOREIGN KEY (`working_City_id`) REFERENCES `city` (`cityid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `country` FOREIGN KEY (`working_Country_id`) REFERENCES `country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `department` FOREIGN KEY (`Department_id`) REFERENCES `department` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `designation` FOREIGN KEY (`Designation_id`) REFERENCES `designation` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `state` FOREIGN KEY (`working_State_id`) REFERENCES `state` (`stateid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'prasad','reddy',2,'2015-02-01',1,2,3,1,'CURRENT_TIMESTAMP',1,40000,'2000-03-02');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `stateid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`stateid`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COMMENT='						';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,'ANDHRA PRADESH'),(2,'ASSAM'),(3,'ARUNACHAL PRADESH'),(4,'GUJRAT'),(5,'BIHAR'),(6,'HARYANA'),(7,'HIMACHAL PRADESH'),(8,'JAMMU & KASHMIR'),(9,'KARNATAKA'),(10,'KERALA'),(11,'MADHYA PRADESH'),(12,'MAHARASHTRA'),(13,'MANIPUR'),(14,'MEGHALAYA'),(15,'MIZORAM'),(16,'NAGALAND'),(17,'ORISSA'),(18,'PUNJAB'),(19,'RAJASTHAN'),(20,'SIKKIM'),(21,'TAMIL NADU'),(22,'TRIPURA'),(23,'UTTAR PRADESH'),(24,'WEST BENGAL'),(25,'GOA'),(26,'PONDICHERY'),(27,'LAKSHDWEEP'),(28,'DAMAN & DIU'),(29,'DADRA & NAGAR'),(30,'CHANDIGARH'),(31,'ANDAMAN & NICOBAR'),(32,'UTTARANCHAL'),(33,'JHARKHAND'),(34,'CHATTISGARH'),(35,'ASSAM');
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-30 19:11:56
